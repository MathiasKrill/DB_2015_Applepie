--SELECT * FROM personal;
--SELECT * FROM projekt;
--SELECT * FROM mitglied_beziehung;

--SELECT * FROM personal, projekt, mitglied_beziehung
--WHERE Personal.personalnr = mitglied_beziehung.personalnr
--AND projekt.projektnr = mitglied_beziehung.projektnr;

--6.1 a
--SELECT * FROM fakultaet, personal;

--6.1 b
--SELECT * FROM fakultaet, personal WHERE abkuerzung = zugehoerigkeit_fk;

--6.1 c
--SELECT personal.name,kurzzeichen,funktion,fakultaet.name FROM fakultaet, personal WHERE abkuerzung = zugehoerigkeit_fk AND personal.funktion = 'Professor';


--6.2 a
--SELECT * FROM personal, mitglied_beziehung, projekt;

----6.2 b
--SELECT * FROM personal, mitglied_beziehung,projekt
--WHERE Personal.personalnr = mitglied_beziehung.personalnr
--AND projekt.projektnr = mitglied_beziehung.projektnr;


--6.2 c

--SELECT personal.name,kurzzeichen,rolle, projekt.titel FROM personal, projekt,mitglied_beziehung
--WHERE Personal.personalnr = mitglied_beziehung.personalnr
--AND projekt.projektnr = mitglied_beziehung.projektnr;

--6.2 d

SELECT personal.name,kurzzeichen,rolle, projekt.titel FROM personal, projekt,mitglied_beziehung
WHERE personal.personalnr = mitglied_beziehung.personalnr(+)
AND  projekt.projektnr(+) = mitglied_beziehung.projektnr;

--6.3 a

SELECT DISTINCT Lehrveranstaltung.titel,personal.name
FROM lehrveranstaltung,personal
WHERE personal.personalnr = lehrveranstaltung.dozent;

--6.3 b

SELECT DISTINCT lehrveranstaltung.titel, lehrveranstaltung.zeit1,lehrveranstaltung.tag1,lehrveranstaltung.zeit2,lehrveranstaltung.tag2,personal.name
FROM lehrveranstaltung,personal
WHERE personal.name = 'Eich';

--6.3 c

-- nicht erlaubt
SELECT p1.name,p1.personalnr,p2.personalnr FROM personal "P1",personal "P2"
WHERE p2.name = 'Schlegel'
AND p1.personalnr > p2.personalnr;


--6.3 d
SELECT p1.name,p1.funktion,p2.funktion FROM personal "P1",personal "P2"
WHERE p2.name= 'Spies' OR p2.name= 'Zwick'
AND p1.funktion = p2.funktion;



-- 6.3 e

SELECT projekt.titel, projekt.projektnr, fakultaet.name FROM projekt, mitglied_beziehung,personal,fakultaet
WHERE projekt.projektnr = mitglied_beziehung.projektnr
AND mitglied_beziehung.personalnr = personal.personalnr
AND personal.zugehoerigkeit_fk = fakultaet.abkuerzung;

