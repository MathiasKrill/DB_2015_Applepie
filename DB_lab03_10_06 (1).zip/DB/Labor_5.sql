/* Aufgabe 5.1 */

--SELECT ABKUERZUNG, Avg(studenten) FROM fakultaet GROUP BY  ABKUERZUNG;

SELECT Avg(studenten) FROM fakultaet ;

SELECT Avg(studenten) "Durchschnittl. Studenten" FROM fakultaet ;

/* Aufgabe 5.2 */


SELECT personalnr, name, kurzzeichen, funktion, zugehoerigkeit_hs,zugehoerigkeit_fk "Z" FROM personal ORDER BY kurzzeichen;


/* Aufgabe 5.4 */
select DISTINCT FUNKTION FROM personal;

SELECT Count(DISTINCT Abkuerzung_FK) FROM Taeger_Beziehung WHERE projektnr IS  NOT null;

/* Aufgabe 5.5 */
SELECT zugehoerigkeit_fk,Count(Name) FROM Personal GROUP BY zugehoerigkeit_fk ;

SELECT zugehoerigkeit_fk  "F", Count(funktion) FROM personal WHERE zugehoerigkeit_fk IS NOT NULL GROUP BY zugehoerigkeit_fk;

SELECT zugehoerigkeit_fk  "F", Count(funktion) FROM personal WHERE zugehoerigkeit_fk IS NOT NULL GROUP BY zugehoerigkeit_fk HAVING count(funktion) >= 3;

SELECT zugehoerigkeit_fk  "F", Count(funktion) FROM personal WHERE Funktion = 'Professor' AND zugehoerigkeit_fk IS NOT NULL GROUP BY zugehoerigkeit_fk HAVING count(funktion) >= 2;

SELECT zugehoerigkeit_fk "F", Min(titelnr) FROM budget GROUP BY zugehoerigkeit_fk;

SELECT * FROM budget;