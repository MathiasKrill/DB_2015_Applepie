
DROP TABLE Beziehung_Auto_Kunde;
drop table Beziehung_Kunde_Gesuch;
drop table Beziehung_kunde_angebot;
drop table Beziehung_Strecken;
drop table Beziehung_Vermittlung;
drop table angebot;
drop table gesuch;
drop table kunde;

drop table auto;
drop table mitarbeiter;

drop table ort;


DROP sequence Mitarbeiterseq;
DROP sequence Kundenseq ;
DROP sequence Gesuchseq;
DROP sequence Angebotseq;
