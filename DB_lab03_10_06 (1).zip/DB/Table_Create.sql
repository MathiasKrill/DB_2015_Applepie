SELECT * FROM Traeger_Beziehung;

/* Tabelle: Hochschule */
DROP TABLE Hochschule;

CREATE TABLE Hochschule(
Abkuerzung VARCHAR(10),
Name VARCHAR(30));

CREATE INDEX i_Abkuerzung$Hochschule ON Hochschule(Abkuerzung);

/* Tabelle: Fakultaet */
DROP TABLE Fakultaet;

CREATE TABLE Fakultaet(
Abkuerzung VARCHAR(1),
Name VARCHAR(50),
Dekan VARCHAR(30),
Studenten NUMBER(3));

CREATE INDEX i_Abkuerzung$Fakultaet ON Fakultaet(Abkuerzung);

/* Tabelle: Budget */
DROP TABLE Budget;

CREATE TABLE Budget(
TitelNr NUMBER(4),
Zugehoerigkeit_HS VARCHAR(5),
Zugehoerigkeit_FK VARCHAR(1));

CREATE INDEX i_TitelNr$Budget ON Budget(TitelNr);

/* Tabelle: Raum */
DROP TABLE Raum;

CREATE TABLE Raum(
RaumNr VARCHAR(10),
Zugehoerigkeit_HS VARCHAR(5),
Zugehoerigkeit_FK VARCHAR(1));

CREATE INDEX i_RaumNr$Raum ON Raum(RaumNr);

/* Tabelle: Personal */
DROP TABLE Personal;

CREATE TABLE Personal(
PersonalNr NUMBER(5),
Name VARCHAR(50),
Kurzzeichen VARCHAR(5),
Funktion VARCHAR(30),
Zugehoerigkeit_HS VARCHAR(5),
Zugehoerigkeit_FK VARCHAR(1));

CREATE INDEX i_RersonalNr$Personal ON Personal(PersonalNr);

/* Tabelle: Lehrveranstaltung */
DROP TABLE Lehrveranstaltung;

CREATE TABLE Lehrveranstaltung(
Titel VARCHAR(5),
Tag VARCHAR(3),
Zeit1 NUMBER(2),
Tag2 VARCHAR(3),
Zeit2 NUMBER(2),
Art VARCHAR(20),
Ort VARCHAR(15),
Dozent NUMBER(5),
Veranstalter VARCHAR(1));

CREATE INDEX i_titel$lehrveranstaltung ON Lehrveranstaltung(Titel);

/* Tabelle: Projekt */
DROP TABLE Projekt;

CREATE TABLE Projekt(
ProjektNr VARCHAR(6),
Titel VARCHAR(50));

CREATE INDEX i_ProjektNr$Projekt ON Projekt(ProjektNr);

/* Tabelle: Mitglied-Beziehung */
DROP TABLE Mitglied_Beziehung;

CREATE TABLE Mitglied_Beziehung(
Rolle VARCHAR(20),
ProjektNr VARCHAR(6),
PersonalNr NUMBER(5));

CREATE INDEX i_ProjektNr$Mitglied_Beziehung ON Mitglied_Beziehung(ProjektNr);

/* Tabelle: Traeger-Beziehung */
DROP TABLE Traeger_Beziehung;

CREATE TABLE Traeger_Beziehung(
ProjektNr VARCHAR(6),
Abkuerzung_Fk VARCHAR(1));

CREATE INDEX i_ProjektNr$Traeger_Beziehung ON Traeger_Beziehung(ProjektNr);

SELECT * FROM Personal;




