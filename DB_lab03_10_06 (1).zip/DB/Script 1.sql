CREATE TABLE
Student(
Name VARCHAR2(20),
Vorname VARCHAR2(20),
StrasseNr VARCHAR2(25),
Postleitzahl NUMBER(5),
Ort VARCHAR2(25),
TelefonNr NUMBER(15),
Studiengang VARCHAR2(3),
MatrikelNr NUMBER(5),
Semester NUMBER(2));