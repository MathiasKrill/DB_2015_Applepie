SELECT * FROM Budget;

/* Tabelle: Hochschule -> INSERT: */
DELETE FROM Hochschule;

INSERT INTO Hochschule(Abkuerzung,Name)
VALUES ('hsma','Hochschule Mannheim');

/* Tabelle: Fakultaet -> INSERT: */
DELETE FROM Fakultaet;

INSERT INTO Fakultaet(Abkuerzung,Name,Dekan,Studenten)
VALUES ('N','Informationstechnik','Prof. Zwick',483);

INSERT INTO Fakultaet(Abkuerzung,Name,Dekan,Studenten)
VALUES ('V','Verfahrenstechnik','Prof. Dr. Hassenpflug',312);

INSERT INTO Fakultaet(Abkuerzung,Name,Dekan,Studenten)
VALUES ('M','Maschinenbau','Prof. Paetzhold',412);

/* Tabelle: Budget -> INSERT: */
DELETE FROM Budget;

INSERT INTO Budget(TitelNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES (1205,NULL,'V');

INSERT INTO Budget(TitelNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES (1277,NULL,'N');

INSERT INTO Budget(TitelNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES (1301,'hsma',NULL);

INSERT INTO Budget(TitelNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES (1324,NULL,'M');

INSERT INTO Budget(TitelNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES (1377,NULL,'N');

/* Tabelle: Raum -> INSERT: */
DELETE FROM Raum;

INSERT INTO Raum(RaumNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES ('3/002',NULL,'V');

INSERT INTO Raum(RaumNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES ('2/112',NULL,'N');

INSERT INTO Raum(RaumNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES ('10/706','hsma',NULL);

INSERT INTO Raum(RaumNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES ('10/306','hsma',NULL);

INSERT INTO Raum(RaumNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES ('11/102',NULL,'M');

INSERT INTO Raum(RaumNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES ('20/220',NULL,'N');

INSERT INTO Raum(RaumNr,Zugehoerigkeit_HS,Zugehoerigkeit_FK)
VALUES ('20/221',NULL,'N');

/* Tabelle: Projekt -> INSERT: */
DELETE FROM Projekt;

INSERT INTO Projekt(ProjektNr,Titel)
VALUES ('95/001','Vermessung von Roentgenbildern');

INSERT INTO Projekt(ProjektNr,Titel)
VALUES ('95/003','Blasenstimulator');

/* Tabelle: Traeger_Beziehung -> INSERT: */
DELETE FROM Traeger_Beziehung;

INSERT INTO Traeger_Beziehung(ProjektNr,Abkuerzung_Fk)
VALUES ('95/001','N');

INSERT INTO Traeger_Beziehung(ProjektNr,Abkuerzung_Fk)
VALUES ('95/003','N');

INSERT INTO Traeger_Beziehung(ProjektNr,Abkuerzung_Fk)
VALUES ('95/003','V');

SELECT * FROM Traeger_Beziehung;


