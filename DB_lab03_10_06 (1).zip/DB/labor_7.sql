--7.1 a
CREATE VIEW GrosseFk AS SELECT * FROM fakultaet WHERE studenten > 400;
SELECT * FROM grossefk;


--7.1 b
SELECT personal.name, personal.funktion, grossefk.name FROM personal,grossefk  WHERE personal.zugehoerigkeit_fk = grossefk.abkuerzung ORDER BY grossefk.name DESC;

--7.1 c
INSERT INTO grossefk (abkuerzung, dekan, studenten) VALUES ('I','Prof. Dr. Winterstein',350);

--7.1 d
DELETE FROM fakultaet WHERE abkuerzung = 'I';

DROP VIEW grossefk;

CREATE VIEW GrosseFk AS SELECT * FROM fakultaet WHERE studenten > 400 WITH CHECK OPTION;

--7.2 a

CREATE VIEW Personalliste AS SELECT personal.name "Mitarbeiter", personal.kurzzeichen "Kuerzel", personal.funktion "Aufgabe", fakultaet.name "Fakultaet"
FROM personal, fakultaet WHERE  personal.zugehoerigkeit_fk = fakultaet.abkuerzung;

SELECT * FROM personalliste;

SELECT mitarbeiter FROM personalliste;
