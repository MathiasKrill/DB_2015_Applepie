Drop Table Budget purge;
Drop Table Lehrveranstaltung purge;
Drop Table Raum purge;
Drop Table Mitglied_Beziehung purge;
Drop Table Taeger_Beziehung;
Drop Table Personal purge;



Drop table Hochschule PURGE;


Drop Table Fakultaet purge;

Drop Table Projekt purge;



Drop sequence Personalnummer ;


Create Sequence Personalnummer
increment by 5
start with 10000 Maxvalue 99999 nocycle;



Create Table Hochschule
(
Abkuerzung VARCHAR(10) constraint primarykey$Hochschule PRIMARY KEY ,
Name VARCHAR(30)
);


Create Table Fakultaet(
Abkuerzung Varchar(1) constraint primarykey$Fakultaet PRIMARY KEY,
Name Varchar(30),
Dekan Varchar(30),
Studenten Number(3)
);

Create Table Budget
(
TitelNr Number(4) constraint TitelNr$Budget PRIMARY KEY,
Zugehoerigkeit_Hs varchar(10) CONSTRAINT Zugehoerigkeit_Hs$Budget REFERENCES Hochschule(Abkuerzung),
Zugehoerigkeit_FK Varchar(1)  CONSTRAINT Zugehoerigkeit_Fk$Budget REFERENCES Fakultaet(Abkuerzung),

CONSTRAINT ZugHsFkNotNull CHECK ( (Zugehoerigkeit_FK IS NOT NULL) AND (Zugehoerigkeit_Hs IS NULL) OR (Zugehoerigkeit_FK IS NULL) AND (Zugehoerigkeit_Hs IS not NULL)  )

);


Create Table Raum(
RaumNr            varchar(10) constraint RaumNr$Raum PRIMARY KEY,
Zugehoerigkeit_Hs varchar(10) CONSTRAINT Zugehoerigkeit_Hs$Raum REFERENCES Hochschule(Abkuerzung),
Zugehoerigkeit_FK varchar(1)  CONSTRAINT Zugehoerigkeit_Fk$Raum REFERENCES Fakultaet(Abkuerzung)

);

Create Table Personal(
PersonalNr        Number(10) CONSTRAINT PersonalNr$Personal PRIMARY KEY,
Name              Varchar(30),
Kurzzeichen       Varchar(5),
Funktion          Varchar(30),
Zugehoerigkeit_Hs varchar(10) CONSTRAINT Zugehoerigkeit_Hs$Personal REFERENCES Hochschule(Abkuerzung),
Zugehoerigkeit_FK varchar(1)  CONSTRAINT Zugehoerigkeit_Fk$Personal REFERENCES Fakultaet(Abkuerzung)

);

Create Table Lehrveranstaltung (
Titel   varchar(5),
Tag1    varchar(2),
Zeit1   Number(1),
Tag2    varchar(2),
Zeit2   number(1),
Art     varchar(20),
Ort     varchar(10) CONSTRAINT ort$Lehrveranstaltung REFERENCES Raum(RaumNr),
Dozent  number(10) CONSTRAINT Dozent$Lehrveranstaltung REFERENCES Personal(PersonalNr),
Veranstalter  varchar(1) CONSTRAINT Veranstalter$Lehrveranstaltung REFERENCES Fakultaet(Abkuerzung),

/*alternativ kann man not null direckt nach number(10) schreiben*/
CONSTRAINT checkDozentNotnull CHECK (Dozent IS NOT NULL)

);

Create Table Projekt (
ProjektNr varchar(10) CONSTRAINT ProjektNr$Projekt PRIMARY key,
Titel varchar(40)
);

Create Table Mitglied_Beziehung(
Rolle varchar(30),
ProjektNr varchar(10) CONSTRAINT ProjektNr$Mitglied_Beziehung REFERENCES Projekt(ProjektNr),
PersonalNr number(10) CONSTRAINT PersonalNr$Mitglied_Beziehung REFERENCES Personal(PersonalNr)
);

Create Table Taeger_Beziehung(
ProjektNr varchar(10) CONSTRAINT ProjektNr$Traeger_Beziehung REFERENCES Projekt(ProjektNr),
Abkuerzung_Fk varchar(1) CONSTRAINT Abkuerzung$Traeger_Beziehung REFERENCES Fakultaet(Abkuerzung)
);

/*Create index i_abkuerzung$Hochschule on Hochschule (Abkuerzung);
Create index i_name$Hochschule on Hochschule (Name);

Create Index i_abkuerzung$Fakultaet on Fakultaet (Abkuerzung);
Create Index i_Name$Fakultaet on Fakultaet (Name);
Create Index i_Studenten$Fakultaet on Fakultaet (Studenten);

Create Index i_TitelNr$Budget on Budget (TitelNr);
Create Index i_RaumNr$Raum on Raum (RaumNr);

Create Index i_PersonalNr$Personal on Personal (PersonalNr);
Create Index i_Name$Personal on Personal (Name);
Create Index i_Kurzzeiche$Personal on Personal (Kurzzeichen);
Create Index i_Funktion$Personal on Personal (Funktion);

Create Index i_Titel$Lehrveranstaltung on Lehrveranstaltung (Titel);
Create Index i_Tag1$Lehrveranstaltung on Lehrveranstaltung (Tag1);
Create Index i_Zeit1$Lehrveranstaltung on Lehrveranstaltung (Zeit1);
Create Index i_Tag2$Lehrveranstaltung on Lehrveranstaltung (Tag2);
Create Index i_Zeit2$Lehrveranstaltung on Lehrveranstaltung (Zeit2);
Create Index i_Art$Lehrveranstaltung on Lehrveranstaltung (Art);

Create Index i_ProjektNr$Projekt on Projekt (ProjektNr);
Create Index i_Titel$Projekt on Projekt (Titel);

Create Index i_Rolle$Mitglied_Beziehung on Mitglied_Beziehung (Rolle);
*/


Insert into Hochschule Values ('hsma','Hochschule Mannheim');

Insert into Fakultaet VALUES('N','Informationstechnik','Prof. Zwick',483);
Insert into Fakultaet VALUES('V','Verfahrenstechnik','Prof. Dr. Hassenpflug',312);
Insert into Fakultaet VALUES('M','Maschinenbau','Prof. Paethold',412);


Insert into Budget  Values(1205,NULL,'V');
Insert into Budget  Values(1277,NULL,'N');
Insert into Budget  Values(1301,'hsma',NULL);
Insert into Budget  Values(1324,NULL,'M');
Insert into Budget  Values(1377,NULL,'N');

Insert into Raum (RaumNr) Values('0/002');
Insert into Raum (RaumNr) Values('2/112');
Insert into Raum (RaumNr) Values('10/706');
Insert into Raum (RaumNr) Values('10/306');
Insert into Raum (RaumNr) Values('11/102');
Insert into Raum (RaumNr) Values('20/220');
Insert into Raum (RaumNr) Values('20/221');

Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Spies','Sp',NULL,'M');
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Schmied','SHI',NULL,'M');
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Schlegel','SHI','hsma',null);
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Eich','EIC',NULL,'N');
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Fuegen','Fue',NULL,'N');
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Paetzhold','PZH',NULL,'M');
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Marquetant','Mq',NULL,'N');
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Zwick','ZWI',NULL,'N');
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Seewaldt','SEW',NULL,'N');
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Hassenpflug','HAS',NULL,'V');
Insert into Personal (PersonalNr,Name,Kurzzeichen,Zugehoerigkeit_HS,Zugehoerigkeit_FK) Values (personalNummer.NEXTVAL,'Hoyningen-Huene','Hoy','hsma',null);


Insert Into Projekt Values('95/001','Vermessung von R�ntgenbildern');
Insert Into Projekt Values('95/003','Blasenstimulator');


Update LEHRVERANSTALTUNG set Ort = '20/222' where Titel= 'DV3';






Update Personal set Funktion = 'Professor';
/*Update Personal set PersonalNr = personalNummer.Nextval;*/

/*
Update Lehrveranstaltung
set Lehrveranstaltung.DOZENT = Personal.PersonalNr
where Personal.Name = 'Eich';
*/

/*
Select Personal Personal.PERSONALNR, Personal.Name from Personal;
*/

Select PersonalNr From Personal where Name = 'Eich';


INSERT INTO Lehrveranstaltung  VALUES('DV3','Do',2,'Fr',1,'Vorlesung','20/221',(SELECT PersonalNr FROM Personal WHERE Name = 'Eich'),'N');
INSERT INTO Lehrveranstaltung  VALUES('DV3','Do',2,'Fr',1,'Vorlesung','20/221',(SELECT PersonalNr FROM Personal WHERE Name = 'Eich'),'N');

Insert Into Mitglied_Beziehung  Values('Analyst','95/001',(SELECT PersonalNr FROM Personal WHERE name = 'Spies'));
Insert Into Mitglied_Beziehung  Values('Projektleiter','95/003',(SELECT PersonalNr FROM Personal WHERE name ='Zwick'));
Insert Into Mitglied_Beziehung  Values('Projektleiter','95/001',(SELECT PersonalNr FROM Personal WHERE name ='Seewaldt'));
Insert Into Mitglied_Beziehung  Values('Archivar','95/001',(SELECT PersonalNr FROM Personal WHERE name ='Marquetant'));



SELECT * FROM Personal;

